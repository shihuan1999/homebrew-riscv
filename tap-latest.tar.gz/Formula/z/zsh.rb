# riscv64_ohos prebuilt dist — ported from Harmonybrew/ohos-*, see build-org-tools.sh
class Zsh < Formula
  desc "Z shell, interactive shell and scripting language"
  homepage "https://www.zsh.org/"
  url "https://github.com/zsh-users/zsh/archive/refs/tags/zsh-5.9.tar.gz"
  sha256 "11ea641122396836441375f41f6cb2954890546857936b734ccad353ab62bf88"
  version "5.9"

  depends_on "ncurses"

  bottle do
    root_url "https://github.com/shihuan1999/homebrew-riscv/releases/download/bottles"
    sha256 cellar: :any_skip_relocation, riscv64_ohos: "167d2a5a5433d77106f56dbf0b25f1cce65e4d6fd40d8b83e33775ef09b373e6"
  end

  resource "ohos_riscv64_dist" do
    url "https://github.com/shihuan1999/homebrew-riscv/releases/download/bottles/zsh-5.9-ohos-riscv64.tar.gz"
    sha256 "5bd81516aab5884cfebb9cbd67b8726c030379154d7e7a69091c3f875ee876c5"
  end

  def install
    resource("ohos_riscv64_dist").stage do
      prefix.install Dir["*"]
    end
  end

  test do
    system "true"
  end
end
